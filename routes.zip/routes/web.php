<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AlunosController;
use App\Http\Controllers\PresencaController;
use App\Http\Controllers\EmpresaController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\EscolhaEmpresaController;

/*
|--------------------------------------------------------------------------
| Web Routes - LABORAL APP (SouTecDigital)
|--------------------------------------------------------------------------
*/

// --- 1. ROTAS PÚBLICAS ---
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

// --- 2. ROTAS PROTEGIDAS (Apenas Autenticados) ---
Route::middleware(['auth'])->group(function () {

    // --- SELEÇÃO DE UNIDADE (Obrigatório após o Login) ---
    Route::get('/escolha-unidade', [EscolhaEmpresaController::class, 'index'])->name('escolha_unidade');
    Route::get('/selecionar-unidade/{id}', [EscolhaEmpresaController::class, 'selecionar'])->name('selecionar_empresa');

    // --- GESTÃO ADMINISTRATIVA (Não dependem de empresa selecionada na sessão) ---
    Route::resource('empresas', EmpresaController::class);
    Route::resource('usuarios', UserController::class);

    // --- 3. ROTAS OPERACIONAIS (Exigem Empresa Ativa na Sessão) ---
    // O Middleware 'check.empresa' vai interceptar qualquer tentativa aqui
    Route::middleware(['check.empresa'])->group(function () {

        // Página Inicial / Dashboard
        Route::get('/', function () {
            return view('welcome');
        })->name('home');

        // --- GESTÃO ADMINISTRATIVA ---
        // Se você quer uma rota específica para a consulta de alunos que criou:     
        Route::get('/alunos', [AlunosController::class, 'index'])->name('alunos.gestao');
        // Módulo de Presenças       
        Route::prefix('presencas')->name('presencas.')->group(function () {
            Route::get('/hoje', [PresencaController::class, 'index'])->name('index'); // Lista de chamada
            Route::get('/registrar', [PresencaController::class, 'create'])->name('registrar'); // Tela de registro manual/QR
            Route::post('/store', [PresencaController::class, 'store'])->name('store'); // Grava no banco


            Route::get('/teste-500', function () {
                return abort(500); // Isso força o Laravel a carregar a sua View de erro
            });


            // Relatório de Presença
            Route::get('/relatorio', [PresencaController::class, 'relatorio'])->name('relatorio');

            
        });
    });
});
